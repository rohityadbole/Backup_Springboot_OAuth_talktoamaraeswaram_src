# two-factor-authentication-springboot

Two Factor Authentication course videos
**********************************************
Hello Everyone,

Here is the Two Factor Authentication course developed by Spring Boot OAUTH2 Security. Course video links are given below.

SMS Authentication - Twilio

Email Authentication - Gmail Transport Layer Security

Please subscribe my youtube channel - https://www.youtube.com/c/Talk2Amareswaran

Please like my Facebook page - https://www.facebook.com/talk2amareswaran/

Introduction - https://youtu.be/uQyYQhXpdak

Database Schema design - https://youtu.be/W1sqlcD9VMs

2FA Authorization - Spring Security OAUTH2 - Authorization server - https://youtu.be/GzgCga5wxDc

2FA Service Implementation - https://youtu.be/5MHxCnlXkEY

2FA CORS - https://youtu.be/PqrwQrkOX5U

Web application integration - https://youtu.be/L_Xap3gBYGI

Two Factor Authentication Playlist - https://www.youtube.com/playlist?list=PL_U4i-WTE-SXpmV_ZfPwppXZzrhQWabDp
