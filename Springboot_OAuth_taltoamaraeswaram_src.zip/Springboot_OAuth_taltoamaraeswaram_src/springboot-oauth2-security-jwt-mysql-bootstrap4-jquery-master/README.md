# springboot-oauth2-security-jwt-mysql-bootstrap4-jquery
Spring Boot OAuth2 Security with MySQL, JWT, Bootstrap4 and JQuery

Introduction - https://youtu.be/JVr56YgMm1I

Role-Based Access Control Database design - https://youtu.be/IZsSKpITIEU

Authorization Server - https://youtu.be/ZIAi8sGHPII

Resource Server - https://youtu.be/lxsUrtcxrog

CORS Support - https://youtu.be/7Yqb275FKmY

Web Application Integration - https://youtu.be/9l_Hn8qzsYw
