# spring-boot2-oauth2-resource-server-jwt-mysqlHello Everyone,

Here is the video of Spring Boot 2.0 Resource Server | OAuth2 | JWT and MySQL

https://youtu.be/fTAXXw-pKH8

Please subscribe my YouTube channel - https://www.youtube.com/c/Talk2Amareswaran

Please like my Facebook page - https://www.facebook.com/talk2amareswaran/

Please join my Facebook group - https://www.facebook.com/groups/271796230307847/

Git hub - https://github.com/talk2amareswaran
